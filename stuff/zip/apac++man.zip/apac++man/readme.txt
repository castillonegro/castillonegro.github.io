A few words...
I created A(nother)Pac++Man for testing/learning purposes. No copyright infringement intended. 
The original graphics, sounds, fonts, idea and... well, whatever... belongs to the original owners.
Pac-Man (c) Namco & Midway Games.
